import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Header } from "@/components/Header";
import { LoginView } from "@/components/LoginView";
import { YouthView } from "@/components/YouthView";
import { ParentView } from "@/components/ParentView";
import { useAppState } from "@/hooks/useAppState";
import type { View, Lang } from "@/types";

export default function App() {
  const [view, setView] = useState<View>("login");
  const [lang, setLang] = useState<Lang>("en");
  const state = useAppState();

  useEffect(() => {
    document.documentElement.style.fontSize = "18px";
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <Header view={view} setView={setView} lang={lang} setLang={setLang} />
      <AnimatePresence mode="wait">
        <motion.main
          key={view}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.25 }}
        >
          {view === "login" && <LoginView lang={lang} onDone={() => setView("youth")} />}
          {view === "youth" && <YouthView lang={lang} state={state} />}
          {view === "parent" && <ParentView lang={lang} state={state} />}
        </motion.main>
      </AnimatePresence>
    </div>
  );
}