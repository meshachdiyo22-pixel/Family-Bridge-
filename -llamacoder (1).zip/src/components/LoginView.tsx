import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, ShieldCheck, Lock, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import type { Lang } from "@/types";

const COPY: Record<Lang, { promise: string; agree: string; notNow: string }> = {
  en: {
    promise:
      "AbokinKa no dey read your chat. E just dey block virus and scam. You see risk first. Parents see only {time, type, blocked}.",
    agree: "Yes, I agree — Connect Us",
    notNow: "Not Now",
  },
  ha: {
    promise:
      "AbokinKa ba ya karanta saƙonka. Yana toshe ƙwayoyin cuta da zamba kawai. Kai ne ka fara ganin haɗari. Iyaye suna ganin {lokaci, iri, toshewa} kawai.",
    agree: "Ee, na yarda — Haɗa Mu",
    notNow: "Ba Yanzu",
  },
  pcm: {
    promise:
      "AbokinKa no dey read your chat. E just dey block virus and scam. You see risk first. Parents see only {time, type, blocked}.",
    agree: "Yes, I agree — Connect Us",
    notNow: "Not Now",
  },
};

export function LoginView({ lang, onDone }: { lang: Lang; onDone: () => void }) {
  const [nin, setNin] = useState("");
  const [phone, setPhone] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [verified, setVerified] = useState(false);
  const [approved, setApproved] = useState<null | boolean>(null);

  const copy = COPY[lang];

  function sendOtp() {
    if (nin.length !== 11 || phone.length < 10) return;
    setOtpSent(true);
    if ("speechSynthesis" in window) {
      const u = new SpeechSynthesisUtterance(
        "Your Family Bridge verification code is 4 8 2 9 1 3. Please say it back to confirm."
      );
      u.rate = 0.95;
      window.speechSynthesis.speak(u);
    }
  }

  function verify() {
    if (otp.replace(/\s/g, "") === "482913") setVerified(true);
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="rounded-2xl border-slate-200 shadow-md">
          <CardHeader>
            <div className="mb-2 inline-flex w-fit items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
              <ShieldCheck className="h-4 w-4" /> Parent Login
            </div>
            <CardTitle className="font-serif text-2xl">Protect your family</CardTitle>
            <CardDescription>NIN + WhatsApp voice OTP. Consent-first, always.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="nin">Parent NIN (11 digits)</Label>
              <Input
                id="nin"
                inputMode="numeric"
                maxLength={11}
                placeholder="12345678901"
                value={nin}
                onChange={(e) => setNin(e.target.value.replace(/\D/g, ""))}
                className="h-14 text-base"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">WhatsApp number</Label>
              <Input
                id="phone"
                inputMode="tel"
                placeholder="+234 801 234 5678"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="h-14 text-base"
              />
            </div>

            {!otpSent ? (
              <Button
                onClick={sendOtp}
                disabled={nin.length !== 11 || phone.length < 10}
                className="h-14 w-full bg-emerald-600 text-base font-semibold hover:bg-emerald-700"
              >
                <Phone className="mr-2 h-5 w-5" /> Send Voice OTP
              </Button>
            ) : (
              <div className="space-y-3 rounded-xl bg-emerald-50 p-4">
                <p className="text-sm text-emerald-800">
                  Voice OTP spoken via WhatsApp. Demo code: <strong>482913</strong>
                </p>
                <Input
                  inputMode="numeric"
                  placeholder="Enter 6-digit code"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  className="h-14 text-base"
                />
                <Button
                  onClick={verify}
                  className="h-14 w-full bg-emerald-600 text-base font-semibold hover:bg-emerald-700"
                >
                  Verify
                </Button>
              </div>
            )}

            {verified && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-2 rounded-xl bg-emerald-100 p-3 text-sm font-semibold text-emerald-800"
              >
                <CheckCircle2 className="h-5 w-5" /> Verified. Request sent to youth for consent.
              </motion.div>
            )}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-sky-200 bg-sky-50 shadow-md">
          <CardHeader>
            <div className="mb-2 inline-flex w-fit items-center gap-2 rounded-full bg-sky-100 px-3 py-1 text-xs font-semibold text-sky-700">
              <Lock className="h-4 w-4" /> Youth Consent
            </div>
            <CardTitle className="font-serif text-2xl">Baba Musa wants to connect</CardTitle>
            <CardDescription>to protect you. Do you agree to share safety summary only?</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-xl border border-sky-200 bg-white p-4 text-sm leading-relaxed text-slate-700">
              {copy.promise}
            </div>
            <p className="text-xs font-semibold uppercase tracking-wide text-sky-700">
              Not your private chats. Ever.
            </p>

            {approved === null && (
              <div className="flex flex-col gap-3">
                <Button
                  onClick={() => {
                    setApproved(true);
                    onDone();
                  }}
                  className="h-16 w-full bg-sky-600 text-base font-semibold hover:bg-sky-700"
                >
                  {copy.agree}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setApproved(false)}
                  className="h-16 w-full border-slate-300 text-base font-semibold"
                >
                  {copy.notNow}
                </Button>
              </div>
            )}

            {approved === true && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 rounded-xl bg-sky-100 p-4 text-sm font-semibold text-sky-800"
              >
                <CheckCircle2 className="h-5 w-5" /> Connected. You can revoke anytime in Me.
              </motion.div>
            )}
            {approved === false && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 rounded-xl bg-slate-100 p-4 text-sm font-semibold text-slate-700"
              >
                <XCircle className="h-5 w-5" /> No sharing. Nothing is collected.
              </motion.div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}