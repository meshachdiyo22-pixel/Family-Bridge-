import { ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import type { View, Lang } from "@/types";

const VIEWS: { id: View; label: string }[] = [
  { id: "login", label: "Login" },
  { id: "youth", label: "Youth" },
  { id: "parent", label: "Parent" },
];

const LANGS: { id: Lang; label: string }[] = [
  { id: "en", label: "EN" },
  { id: "ha", label: "HA" },
  { id: "pcm", label: "PCM" },
];

export function Header({
  view,
  setView,
  lang,
  setLang,
}: {
  view: View;
  setView: (v: View) => void;
  lang: Lang;
  setLang: (l: Lang) => void;
}) {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-3 px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-sky-500 to-emerald-500 text-white shadow-sm">
            <ShieldCheck className="h-6 w-6" />
          </span>
          <div className="leading-tight">
            <p className="font-serif text-lg font-bold">Family Bridge</p>
            <p className="text-xs text-muted-foreground">Gadar Iyali · AI that connects, not spies</p>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <div className="flex rounded-full bg-slate-100 p-1">
            {VIEWS.map((v) => (
              <button
                key={v.id}
                onClick={() => setView(v.id)}
                className={cn(
                  "min-h-11 rounded-full px-4 text-sm font-semibold transition",
                  view === v.id ? "bg-slate-900 text-white shadow" : "text-slate-600 hover:text-slate-900"
                )}
              >
                {v.label}
              </button>
            ))}
          </div>
          <div className="flex rounded-full bg-slate-100 p-1">
            {LANGS.map((l) => (
              <button
                key={l.id}
                onClick={() => setLang(l.id)}
                className={cn(
                  "min-h-11 rounded-full px-3 text-sm font-semibold transition",
                  lang === l.id ? "bg-sky-600 text-white shadow" : "text-slate-600 hover:text-slate-900"
                )}
              >
                {l.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}