import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldCheck,
  Flame,
  Wallet,
  BookOpen,
  Sparkles,
  Send,
  Eye,
  Lock,
  Home,
  MessageCircle,
  User,
  Award,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { AppState, Lang } from "@/types";

const TIPS = [
  "Never send your photo to someone you don't know in person. Block and tell a trusted adult.",
  "If a stranger asks for money or your bank PIN, it is a scam. Do not reply.",
  "Keep your passwords private — not even your best friend needs them.",
];

export function YouthView({ lang, state }: { lang: Lang; state: AppState }) {
  const [tab, setTab] = useState<"home" | "safety" | "chat" | "me">("home");
  const [showTrust, setShowTrust] = useState(false);
  const [mentorDone, setMentorDone] = useState(false);
  const [chat, setChat] = useState<{ role: "user" | "ai"; text: string }[]>([]);
  const [msg, setMsg] = useState("");
  const [popBadge, setPopBadge] = useState<string | null>(null);

  const level = Math.floor(state.xp / 100) + 1;
  const intoLevel = state.xp % 100;
  const pct = intoLevel;

  function giveTip() {
    state.addXp(20);
    state.earnBadge("Scam Slayer");
    setMentorDone(true);
    setPopBadge("Scam Slayer");
    toast.success("+20 XP · Badge unlocked: Scam Slayer");
    setTimeout(() => setPopBadge(null), 1800);
  }

  function okay() {
    state.addXp(10);
    setMentorDone(true);
    toast.success("+10 XP");
  }

  function redeem() {
    const ok = state.redeem();
    if (ok) toast.success("Request sent to Baba Musa for approval");
    else toast.error("Need 100 XP");
  }

  function sendChat() {
    if (!msg.trim()) return;
    const q = msg.trim();
    setChat((c) => [...c, { role: "user", text: q }]);
    setMsg("");
    const tip = TIPS[Math.floor(Math.random() * TIPS.length)];
    setTimeout(() => {
      setChat((c) => [
        ...c,
        {
          role: "ai",
          text: `${tip}\n\nI will not tell your parent. This stays private. 🔒`,
        },
      ]);
      state.addXp(20);
      toast.success("+20 XP · Private advice");
    }, 500);
  }

  return (
    <div className="mx-auto max-w-md px-4 pb-28 pt-6">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-sky-500 text-white shadow-md">
            <ShieldCheck className="h-6 w-6" />
          </span>
          <div>
            <p className="font-serif text-lg font-bold">AbokinKa</p>
            <p className="text-xs text-muted-foreground">My Day Guard</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1 text-sm font-bold text-amber-700">
            <Flame className="h-4 w-4" /> {state.streak}
          </span>
          <span className="grid h-10 w-10 place-items-center rounded-full bg-slate-900 text-sm font-bold text-white">
            M
          </span>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {tab === "home" && (
          <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="overflow-hidden rounded-2xl border-0 bg-gradient-to-br from-sky-500 to-sky-700 text-white shadow-lg">
              <CardContent className="p-5">
                <p className="text-sm opacity-90">XP Balance</p>
                <p className="font-serif text-3xl font-bold">
                  {state.xp} XP <span className="text-base opacity-80">/ {level * 100} XP</span>
                </p>
                <p className="mt-1 text-sm">Level {level}</p>
                <div className="mt-3 h-3 w-full overflow-hidden rounded-full bg-white/25">
                  <div className="h-full rounded-full bg-white" style={{ width: `${pct}%` }} />
                </div>
                <p className="mt-2 text-xs opacity-90">{100 - intoLevel} XP to Level {level + 1}</p>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-2 border-dashed border-amber-400 bg-amber-50 shadow-sm">
              <CardContent className="flex items-center gap-3 p-5">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-amber-400 text-white">
                  <Wallet className="h-6 w-6" />
                </span>
                <div className="flex-1">
                  <p className="font-semibold text-amber-900">100 XP = ₦100 airtime</p>
                  <p className="text-xs text-amber-700">Redeem for MTN, Airtel, Glo, 9mobile</p>
                </div>
                <Button onClick={redeem} className="h-12 bg-sky-600 px-5 font-semibold hover:bg-sky-700">
                  Redeem
                </Button>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-slate-200 shadow-sm">
              <CardContent className="p-5">
                <div className="mb-2 flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-sky-600" />
                  <p className="font-semibold">Sannu Musa! Today you did well</p>
                </div>
                <p className="text-sm text-muted-foreground">3 hours reading, well done!</p>
                <div className="mt-3 h-3 w-full overflow-hidden rounded-full bg-slate-100">
                  <div className="h-full rounded-full bg-sky-500" style={{ width: "75%" }} />
                </div>
                <p className="mt-2 text-xs text-muted-foreground">3h / 4h · +20 XP</p>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-emerald-200 bg-emerald-50 shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-start gap-3">
                  <span className="grid h-14 w-14 shrink-0 place-items-center rounded-full bg-emerald-600 text-2xl">
                    🧕
                  </span>
                  <div className="flex-1">
                    <p className="font-semibold text-emerald-900">Baba Llama Mentor</p>
                    <p className="mt-1 text-sm text-emerald-800">
                      Oga, I block one site wey fit spoil your phone. You handle am like boss! Want +20 XP tip?
                    </p>
                    {!mentorDone ? (
                      <div className="mt-3 flex flex-col gap-2">
                        <Button onClick={giveTip} className="h-12 bg-emerald-600 font-semibold hover:bg-emerald-700">
                          Yes, give tips +20 XP
                        </Button>
                        <Button
                          variant="outline"
                          onClick={okay}
                          className="h-12 border-emerald-300 font-semibold text-emerald-800"
                        >
                          I'm okay +10 XP
                        </Button>
                      </div>
                    ) : (
                      <p className="mt-3 text-sm font-semibold text-emerald-700">Tip received. Keep going! 💪</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <div>
              <p className="mb-2 flex items-center gap-2 font-semibold">
                <Award className="h-5 w-5 text-amber-500" /> Badges
              </p>
              <div className="flex flex-wrap gap-2">
                {["Data Guard", "Reading Champ", "Scam Slayer"].map((b) => {
                  const earned = state.badges.includes(b);
                  return (
                    <motion.span
                      key={b}
                      animate={popBadge === b ? { scale: [1, 1.3, 1] } : {}}
                      className={cn(
                        "rounded-full px-4 py-2 text-sm font-semibold",
                        earned ? "bg-amber-400 text-amber-950 shadow" : "bg-slate-100 text-slate-400"
                      )}
                    >
                      {earned ? "🏅 " : "🔒 "}
                      {b}
                    </motion.span>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}

        {tab === "safety" && (
          <motion.div key="safety" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="rounded-2xl border-sky-200 bg-sky-50 shadow-sm">
              <CardContent className="p-5">
                <p className="font-serif text-xl font-bold">Your safety today</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  All checks run on your device. Nothing raw is stored.
                </p>
                <div className="mt-4 space-y-3">
                  {[
                    { t: "10:42pm", type: "Adult content", action: "Blocked" },
                    { t: "4:15pm", type: "Scam link", action: "Blocked" },
                  ].map((r) => (
                    <div key={r.t} className="flex items-center justify-between rounded-xl bg-white p-4 shadow-sm">
                      <div>
                        <p className="font-semibold">{r.type}</p>
                        <p className="text-xs text-muted-foreground">{r.t}</p>
                      </div>
                      <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-bold text-red-700">
                        {r.action}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={() => setShowTrust((s) => !s)}
              className="h-14 w-full bg-slate-900 text-base font-semibold hover:bg-slate-800"
            >
              <Eye className="mr-2 h-5 w-5" /> See What My Parents See
            </Button>

            <AnimatePresence>
              {showTrust && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}>
                  <Card className="rounded-2xl border-slate-200 shadow-sm">
                    <CardContent className="p-5">
                      <p className="mb-3 flex items-center gap-2 font-semibold">
                        <Lock className="h-4 w-4 text-emerald-600" /> Parent view (metadata only)
                      </p>
                      <pre className="overflow-x-auto rounded-xl bg-slate-900 p-4 text-xs text-emerald-300">
{`{
  "time": "10:42pm",
  "type": "Adult content",
  "count": 1,
  "action": "blocked"
}`}
                      </pre>
                      <p className="mt-3 text-xs text-muted-foreground">
                        No chat content. No images. No call audio. Ever.
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {tab === "chat" && (
          <motion.div key="chat" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="rounded-2xl border-slate-200 shadow-sm">
              <CardContent className="p-5">
                <p className="flex items-center gap-2 font-serif text-xl font-bold">
                  Ask Baba Anything <Lock className="h-4 w-4 text-emerald-600" />
                </p>
                <p className="text-sm text-muted-foreground">Private. Your parent never sees this.</p>
              </CardContent>
            </Card>

            <div className="space-y-3">
              {chat.length === 0 && (
                <button
                  onClick={() => setMsg("Someone asked for my photo, what should I do?")}
                  className="w-full rounded-2xl border border-sky-200 bg-sky-50 p-4 text-left text-sm font-medium text-sky-800 transition hover:bg-sky-100"
                >
                  💬 Someone asked for my photo, what should I do?
                </button>
              )}
              {chat.map((m, i) => (
                <div
                  key={i}
                  className={cn(
                    "max-w-[85%] whitespace-pre-line rounded-2xl p-4 text-sm shadow-sm",
                    m.role === "user"
                      ? "ml-auto bg-sky-600 text-white"
                      : "bg-white text-slate-800"
                  )}
                >
                  {m.text}
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <Input
                value={msg}
                onChange={(e) => setMsg(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendChat()}
                placeholder="Someone asked for my photo..."
                className="h-14 text-base"
              />
              <Button onClick={sendChat} className="h-14 bg-sky-600 px-5 hover:bg-sky-700">
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </motion.div>
        )}

        {tab === "me" && (
          <motion.div key="me" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="rounded-2xl border-slate-200 shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <span className="grid h-16 w-16 place-items-center rounded-full bg-slate-900 text-xl font-bold text-white">
                    M
                  </span>
                  <div>
                    <p className="font-serif text-xl font-bold">Musa</p>
                    <p className="text-sm text-muted-foreground">Level {level} · {state.xp} XP</p>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="rounded-xl bg-sky-50 p-4">
                    <p className="text-xs text-sky-700">Streak</p>
                    <p className="font-bold text-sky-900">{state.streak} days 🔥</p>
                  </div>
                  <div className="rounded-xl bg-amber-50 p-4">
                    <p className="text-xs text-amber-700">Airtime</p>
                    <p className="font-bold text-amber-900">₦{state.airtime * 100}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-red-200 bg-red-50 shadow-sm">
              <CardContent className="p-5">
                <p className="font-semibold text-red-800">Revoke consent</p>
                <p className="mt-1 text-sm text-red-700">
                  Stop sharing your safety summary with Baba Musa anytime.
                </p>
                <Button
                  variant="outline"
                  onClick={() => toast.success("Consent revoked. Nothing is shared.")}
                  className="mt-3 h-12 border-red-300 font-semibold text-red-700"
                >
                  Revoke now
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center justify-around px-2 py-2">
          {[
            { id: "home", label: "Home", icon: Home },
            { id: "safety", label: "Safety", icon: ShieldCheck },
            { id: "chat", label: "Chat", icon: MessageCircle },
            { id: "me", label: "Me", icon: User },
          ].map((n) => {
            const Icon = n.icon;
            const active = tab === n.id;
            return (
              <button
                key={n.id}
                onClick={() => setTab(n.id as typeof tab)}
                className={cn(
                  "flex min-h-14 flex-1 flex-col items-center justify-center gap-1 rounded-xl text-xs font-semibold transition",
                  active ? "text-sky-600" : "text-slate-400 hover:text-slate-600"
                )}
              >
                <Icon className="h-6 w-6" />
                {n.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}