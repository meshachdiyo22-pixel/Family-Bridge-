import { motion } from "framer-motion";
import { ShieldCheck, AlertTriangle, CheckCircle2, Gift, Flame, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import type { AppState, Lang } from "@/types";

export function ParentView({ lang, state }: { lang: Lang; state: AppState }) {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <section className="overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 to-emerald-800 p-8 text-white shadow-xl">
        <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-xs font-semibold">
          <ShieldCheck className="h-4 w-4" /> familybridge.ng
        </span>
        <h1 className="mt-4 max-w-2xl font-serif text-3xl font-bold leading-tight md:text-4xl">
          Yaro yana waya dare da rana? Ba ka san waye yake magana da shi ba?
        </h1>
        <p className="mt-3 max-w-2xl text-emerald-50">
          Family Bridge helps you know if he is safe, without reading his private chats.
        </p>
        <Button
          onClick={() => toast.success("Welcome! Consent request sent to Musa.")}
          className="mt-6 h-14 bg-amber-400 px-6 text-base font-bold text-emerald-950 hover:bg-amber-300"
        >
          Start Protecting My Family — Free
        </Button>
      </section>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="rounded-2xl border-emerald-200 bg-emerald-50 shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-emerald-600 text-white">
                    <CheckCircle2 className="h-6 w-6" />
                  </span>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wide text-emerald-700">Today</p>
                    <p className="font-serif text-2xl font-bold text-emerald-900">SAFE</p>
                  </div>
                </div>
                <p className="mt-4 text-emerald-900">
                  Musa spent 3 hours online. No threat today.
                </p>
                <div className="mt-4 grid grid-cols-3 gap-3">
                  <div className="rounded-xl bg-white p-3 text-center shadow-sm">
                    <p className="text-xs text-muted-foreground">XP today</p>
                    <p className="font-bold text-emerald-700">+40 XP</p>
                  </div>
                  <div className="rounded-xl bg-white p-3 text-center shadow-sm">
                    <p className="text-xs text-muted-foreground">Streak</p>
                    <p className="flex items-center justify-center gap-1 font-bold text-amber-600">
                      <Flame className="h-4 w-4" /> {state.streak}
                    </p>
                  </div>
                  <div className="rounded-xl bg-white p-3 text-center shadow-sm">
                    <p className="text-xs text-muted-foreground">Airtime</p>
                    <p className="font-bold text-slate-800">₦{state.airtime * 100}</p>
                  </div>
                </div>

                {state.pendingReward && (
                  <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-dashed border-amber-400 bg-amber-50 p-4">
                    <div className="flex items-center gap-2">
                      <Gift className="h-5 w-5 text-amber-600" />
                      <p className="text-sm font-semibold text-amber-900">
                        Musa requested ₦100 airtime reward
                      </p>
                    </div>
                    <Button
                      onClick={() => {
                        state.approveReward();
                        toast.success("₦100 airtime reward approved for Musa");
                      }}
                      className="h-12 bg-emerald-600 px-5 font-semibold hover:bg-emerald-700"
                    >
                      Approve ₦100 Airtime Reward
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            <Card className="rounded-2xl border-amber-300 bg-amber-50 shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-amber-400 text-amber-950">
                    <AlertTriangle className="h-6 w-6" />
                  </span>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wide text-amber-700">10:42pm</p>
                    <p className="font-serif text-2xl font-bold text-amber-900">Adult content</p>
                  </div>
                </div>
                <p className="mt-4 text-amber-900">
                  Blocked automatically on Musa's device. He was shown a supportive coaching tip first.
                </p>
                <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold">
                  <span className="rounded-full bg-white px-3 py-1 text-amber-800 shadow-sm">time: 10:42pm</span>
                  <span className="rounded-full bg-white px-3 py-1 text-amber-800 shadow-sm">type: adult</span>
                  <span className="rounded-full bg-white px-3 py-1 text-amber-800 shadow-sm">count: 1</span>
                  <span className="rounded-full bg-red-100 px-3 py-1 text-red-700 shadow-sm">action: blocked</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <div className="space-y-6">
          <Card className="rounded-2xl border-slate-200 shadow-md">
            <CardContent className="p-6">
              <p className="flex items-center gap-2 font-semibold">
                <Clock className="h-5 w-5 text-slate-500" /> Privacy promise
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                You only ever see metadata: time, type, count, and action taken. Never chats, images, or call audio.
              </p>
              <div className="mt-4 rounded-xl bg-slate-900 p-4 text-xs text-emerald-300">
                <pre>{`{
  "time": "10:42pm",
  "type": "Adult content",
  "count": 1,
  "action": "blocked"
}`}</pre>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-sky-200 bg-sky-50 shadow-md">
            <CardContent className="p-6">
              <p className="font-semibold text-sky-900">Musa's badges</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {["Data Guard", "Reading Champ", "Scam Slayer"].map((b) => (
                  <span
                    key={b}
                    className={
                      state.badges.includes(b)
                        ? "rounded-full bg-amber-400 px-3 py-1 text-xs font-bold text-amber-950"
                        : "rounded-full bg-white px-3 py-1 text-xs font-semibold text-slate-400"
                    }
                  >
                    {b}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}