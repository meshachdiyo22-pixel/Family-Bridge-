import { useState, useCallback, useEffect } from "react";
import type { AppState } from "@/types";

const KEY = "familybridge_state_v1";

interface Persisted {
  xp: number;
  streak: number;
  airtime: number;
  badges: string[];
  pendingReward: boolean;
}

function load(): Persisted {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* noop */
  }
  return { xp: 120, streak: 3, airtime: 1, badges: ["Data Guard"], pendingReward: false };
}

export function useAppState(): AppState {
  const [s, setS] = useState<Persisted>(load);

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(s));
  }, [s]);

  const addXp = useCallback((n: number) => {
    setS((p) => ({ ...p, xp: p.xp + n }));
  }, []);

  const redeem = useCallback(() => {
    let ok = false;
    setS((p) => {
      if (p.xp >= 100) {
        ok = true;
        return { ...p, xp: p.xp - 100, airtime: p.airtime + 1, pendingReward: true };
      }
      return p;
    });
    return ok;
  }, []);

  const approveReward = useCallback(() => {
    setS((p) => ({ ...p, pendingReward: false, airtime: Math.max(0, p.airtime - 1) }));
  }, []);

  const earnBadge = useCallback((b: string) => {
    setS((p) => (p.badges.includes(b) ? p : { ...p, badges: [...p.badges, b] }));
  }, []);

  return {
    xp: s.xp,
    streak: s.streak,
    airtime: s.airtime,
    readingHours: 3,
    badges: s.badges,
    pendingReward: s.pendingReward,
    addXp,
    redeem,
    approveReward,
    earnBadge,
  };
}