export type View = "login" | "youth" | "parent";
export type Lang = "en" | "ha" | "pcm";

export interface AppState {
  xp: number;
  streak: number;
  airtime: number;
  readingHours: number;
  badges: string[];
  pendingReward: boolean;
  addXp: (n: number) => void;
  redeem: () => boolean;
  approveReward: () => void;
  earnBadge: (b: string) => void;
}